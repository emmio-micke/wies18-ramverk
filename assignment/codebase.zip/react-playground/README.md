# React Playground
Kodbasen är ett grundläggande React och Typescript projekt och är utgångspunkten för
inlämningsuppgift 2 i Ramverkskursen.


## Användning

Lägg till din egna access_key från www.unsplash.com i filen `imageSection.tsx`.
Kör först ```npm install``` sedan ```npm run app``` för att starta.


## LYCKA TILL!